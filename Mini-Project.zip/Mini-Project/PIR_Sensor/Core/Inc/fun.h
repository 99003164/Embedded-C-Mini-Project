/*
 * fun.h
 *
 *  Created on: Jan 2, 2021
 *      Author: 99003164
 */
#ifndef INC_FUN_H_
#define INC_FUN_H_

#include <stdint.h>
#include "main.h"

void syst_beg(uint8_t);
uint16_t Ana_Rd(ADC_HandleTypeDef);


#endif /* INC_FUN_H_ */
